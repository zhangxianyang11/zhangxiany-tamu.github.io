####################################
####################################
## R-3.2.0 and above is required  ##
####################################
####################################


##  Rcpp (>= 0.12.10) is required

install.packages("Rcpp")

# replace "PATH" with local Path

install.packages("~/PATH/dCovMutualTest_0.1.0.tgz", repos = NULL, type = .Platform$pkgType)


library(dCovMutualTest)

set.seed(100)

n <- 30
p <- 100
x <- matrix(rnorm(n*p),n,p)

dCovMutualTest(x)

#> dCovMutualTest(x)
#[1] 0.3698037
