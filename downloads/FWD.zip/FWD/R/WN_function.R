#' Bootstrap-assisted spectra-based test for white noise testing 
#' @param X: R times N matrix, where N is the sample size and R is the number of observations for each curve.
#' @param bsize: Block size in the block bootstrap method. If bsize is "auto", the minimal volatility method is used to select the block size.
#' @param M: Number of bootstrap replications.
#' @param nbasis: Number of B-spline basis functions.
#' @param P: Number of pieces used to approximate integrals using the Riemann sums. 
#' @return P-value and whether the test is rejected at the nominal levels 10\%, 5\%, and 1\%.
#' @examples
#' # A small simulation study
#' # The data are i.i.d Brownian motions
#' # The number of replications is 100
#' # The sample size is 101
#'
#' set.seed(3)
#' N <- 101
#' rej <- matrix(NA,100,3)
#' for(i in 1:100)
#' {
#' xr <- matrix(rnorm(1000*N,0,1),1000,N)
#' xr <- rbind(0,xr)
#' BM <- apply(xr,2,cumsum)/sqrt(1000)
#' rej[i,] <- WN.test(X=BM, bsize=1, M=299)[[1]]
#' if(i%%10==0) print(i)
#' }
#' erej <- apply(rej,2,mean)
#' erej

WN.test <- function(X, bsize="auto", M=500, nbasis=20, P=50)
{
quan <- rep(NA,3)
R <- dim(X)[1]
N <- dim(X)[2]

if(bsize=="auto")  block <- 1:floor(N^(1/2)) else block <- bsize
basis <- create.bspline.basis(rangeval=c(0,1), nbasis=nbasis, norder=4)
fd.data <- smooth.basis(0:(R-1)/(R-1), X, basis)$fd

# Compute the spectra-based test

data <- eval.fd(fd.data,1:P/P)
covm <- array(NA, c(P,P,N-1))
ncov <- rep(NA, N-1)
for(h in 1:(N-1))
 {
 Gamma <- data[,(1+h):N]%*%t(data[,1:(N-h)])/N
 covm[,,h] <- Gamma+t(Gamma)
 ncov[h] <- sum(covm[,,h]^2)/P^2
 }
stat <- sum(ncov/(1:(N-1))^2)/pi^2*N/8

# Block bootstrap

qb <- matrix(NA,length(block),3)
pvalue <- rep(NA,length(block))
for(cc in 1:length(block))
 {
 bN <- block[cc]
 MN <- floor((N-1)/bN)
 stat.b <- rep(NA,M)
 for(bt in 1:M)
  {
  b <- sample(MN, MN, replace=TRUE)
  index <- as.vector(t(matrix((b-1)*bN, MN, bN))+(1:bN))
  if(length(index)<N-1) 
   {
   ab <- (sample(MN, 1, replace=TRUE)-1)*bN+(1:bN)
   index <- c(index,ab)[1:(N-1)]
   }
  index <- index+1
  ncovb <- rep(NA,N-1)
  covb1 <- matrix(0,P,P)
  for(hb in 1:(N-1))
   {
   ind <- index[(index-hb)>=1]
   Gb <- data[,ind]%*%t(data[,ind-hb])/N
   covb <- Gb+t(Gb)-covm[,,hb]*length(ind)/N
   ncovb[hb] <- sum(covb^2)/P^2
   covb1 <- covb^2/hb^2+covb1
   }
  stat.b[bt] <- sum(ncovb/(1:(N-1))^2)/pi^2*N/8
  }
 qb[cc,] <- quantile(stat.b,c(0.90,0.95,0.99))
 pvalue[cc] <- mean(stat.b > stat)
 }

# Minimum volatility method

if(bsize=="auto")
 {
 sb <- matrix(NA,length(block),3)
 for(cc in 1:length(block))
  {
  id <- max((cc-3),1):min((cc+3),length(block))
  sb[cc,] <- apply(qb[id,],2,sd)
  }
 for(L in 1:3) quan[L] <- qb[which.min(sb[,L]),L]
 } else 
  {
  quan <- qb
  }

ret <- matrix(stat>quan,1,3)
colnames(ret) <- c("10%","5%","1%")
if(bsize!="auto") ret<-list(rejection=ret, pvalue=c(pvalue))
return(ret)
}