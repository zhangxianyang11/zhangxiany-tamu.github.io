# This package contains the R functions implementing the bootstrap-assisted spectra-based tests. 
# See Zhang, X. (2015) White Noise Testing and Model Diagnostic Checking for Functional Time Series
# Require the R package {fda} 